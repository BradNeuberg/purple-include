<?

// this file under the public domain

// turn off all error reporting
error_reporting(0); 

$url = $_GET['url'];

// only http and https supported
if(preg_match("/^https?\:.*/", $url)){
	$html = file_get_contents($url);
	
	// TODO: make sure we have XML and not some other
	// content type or an error message

	// get the status code of the response	
	list($version, $status_code, $msg) = explode(' ', $http_response_header[0], 3);
	switch($status_code){
   		case 200: case 304:
			header('Content-type: text/html');
			echo($html);
			break;
		default:
			header($http_response_header[0]);
			break;
	}
}else{
	header('HTTP/1.1 403 Forbidden');
	header('Content-type: text/html');
	echo("You are not allowed to retrieve this resource");
}
?>

