/* 
	Copyright 2007 Bootstrap Foundation.

	This code is based on the HyperScope XHTML Transformer, and is therefore
	under the GPL Version 2 or later.
	
	@author Brad Neuberg 
*/

package org.hyperscope.purple.include;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.*;

import org.w3c.tidy.*;

import javax.xml.*;
import javax.xml.xpath.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;

import net.sf.saxon.om.*;
import net.sf.saxon.xpath.*;
import net.sf.saxon.trans.*;

import org.xml.sax.*;

public class PurpleInclude{
	private String path;

	public PurpleInclude(){
		System.setProperty("javax.xml.transform.TransformerFactory", 
							"net.sf.saxon.TransformerFactoryImpl");			
		System.setProperty(
				"javax.xml.xpath.XPathFactory:"+NamespaceConstant.OBJECT_MODEL_SAXON,
                "net.sf.saxon.xpath.XPathFactoryImpl");
	}
	
	/**
		Entry point for fetching a given URL, tidying it up,
		transforming it into XHTML,
		and then applying a given in-file address to it.
		
		@param fetchMe String url to fetch. Security will be done
		on this url to make sure it is safe to fetch.
		@param address The in-file expression to apply to this
		document, such as an xpath expression.
		@param beSecure Boolean variable that controls whether we check
		to make sure URL's are safe. If true, then we filter out unsafe schemes
		and localhost; if false, then we don't.
		@returns The fragment results.
	*/
	public String exec(String fetchMe, String address, 
							boolean beSecure)
							throws Exception{
		// get the URL to fetch and make sure it is safe
		URL url = toURL(fetchMe, beSecure);
		
		// get the content
		String html = getContent(url);
		
		// tidy up the content and turn it
		// into XML (XHTML)
		String xml = tidyHTML(html);
		
		// apply the infile-address expression
		String fragment = applyAddress(xml, address);
		
		return fragment;
	}

	private URL toURL(String fetchMe, boolean beSecure) throws SecurityException{
		if(fetchMe == null || fetchMe.trim().equals("")){
			throw new SecurityException("No URL provided");
		}
		
		try{
			URL url = new URL(fetchMe);
			
			if(beSecure){
				// secure protocol?
				if(!url.getProtocol().equals("http") &&
					!url.getProtocol().equals("https")){
					throw new SecurityException("Protocol not allowed");
				}
					
				// Loopback address or DNS name that is
				// only resolvable behind the firewall?
				if(url.getHost().equals("localhost")
					|| url.getHost().equals("127.0.0.1")
					|| url.getHost().indexOf(".local") != -1
					|| url.getHost().indexOf(".") == -1){
					throw new SecurityException("You do not have permission "
												+ "to access this host");
				}
			}
			
			return url;
		}catch(MalformedURLException e){
			throw new SecurityException("Malformed URL");
		}
	}
	
	private String getContent(URL url) 
						throws HttpException,
								IOException,
								SecurityException{
		// get the contents
		HttpClient client = new HttpClient();
		HttpMethod method = new GetMethod(url.toString());
		int statusCode = client.executeMethod(method);
		
		// make sure it executed correctly
		if(statusCode != HttpStatus.SC_OK){
			throw new HttpException("Request failed: "
									+ method.getStatusLine());
		}
		
		// make sure we have HTML or XHTML
		String mimeType = method.getResponseHeader("Content-type").toString();
		if(mimeType.indexOf("text/html") == -1
			&& mimeType.indexOf("application/xhtml+xml") == -1
			&& mimeType.indexOf("text/xml") == -1
			&& mimeType.indexOf("application/xml") == -1){
				throw new SecurityException("Insecure MIME type returned");
		}
		
		// get the actual response returned; should automatically
		// use the underlying response character encoding when
		// creating the string
		String content = method.getResponseBodyAsString();
		
		method.releaseConnection();
		
		return content;
	}
	
	private String tidyHTML(String content)
									throws IOException{
		Tidy tidy = new Tidy();
		
		// set configuration values
		tidy.setDropEmptyParas(false); // drop empty P elements
		tidy.setDocType("omit"); // omit the doctype
		tidy.setEncloseBlockText(true); // wrap blocks of text in P elements
		tidy.setEncloseText(true); // wrap text right under BODY element in P elements
		tidy.setHideEndTags(false); // force optional end tags
		tidy.setIndentContent(true); // indent content for easy reading
		tidy.setLiteralAttribs(false); // no new lines in attributes
		tidy.setLogicalEmphasis(false); // replace i and b by em and strong, respectively
		tidy.setMakeClean(false); // strip presentational cruft
		tidy.setNumEntities(true); // convert entities to their numeric form
		tidy.setWord2000(true); // strip Word 2000 cruft
		tidy.setXHTML(true); // output XHTML
		tidy.setXmlPi(true); // add <?xml?> processing instruction
		
		// parse
		StringReader in = new StringReader(content);
		StringWriter out = new StringWriter();
		tidy.parse(in, out);
		in.close();
		out.close();
		String results = out.toString();
		
		// remove the XML namespace declaration,
		// since it makes trouble for us in the XPath
		// evaluator
		// FIXME: this is ghetto and needs to be fixed
		// with a namespace evaluator in the XPath section,
		// but namespace evaluators are a pain in the butt
		// to get working
		
		// String.replace() does not work on 1.4 JVMs when compiled
		// with 1.5 JVMs, even with target="1.4" (this is a known Java
		// bug). Using workaround instead. -- Brad Neuberg
		//results = results.replace("xmlns=\"http://www.w3.org/1999/xhtml\"", "");
		
		StringBuffer buffer = new StringBuffer(results);
		int startCut = buffer.indexOf("xmlns=\"http://www.w3.org/1999/xhtml\"");
		if(startCut != -1){
			buffer.replace(startCut, 
							startCut + "xmlns=\"http://www.w3.org/1999/xhtml\"".length(), 
							"");
			results = buffer.toString();
		}
				
		return results;
	}
	
	private String applyAddress(String content, String address) 
									throws Exception{
		address = normalizeAddress(address);
		System.out.println("after normalizing, address="+address);
		StringBuffer results = new StringBuffer();
		
		address = address.substring("xpath(".length());
		address = address.substring(0, address.length() - 1);
		System.out.println("After parsing address from XPath expression, address="+address);

        XPathFactory xpf = XPathFactory.newInstance(NamespaceConstant.OBJECT_MODEL_SAXON);
        XPath xpe = xpf.newXPath();
		
		Source source = (Source)new StreamSource(new StringReader(content));
		NodeInfo doc = ((XPathEvaluator)xpe).setSource(source);
		
		List matches = (List)xpe.evaluate(address, doc, XPathConstants.NODESET);
		Iterator it = matches.iterator();
		while(it.hasNext()){
			NodeInfo node = (NodeInfo)it.next();
			System.out.println("node="+node);
			// serialize results
			TransformerFactory factory = TransformerFactory.newInstance();
			Transformer serializer = factory.newTransformer();
    
			StringWriter output = new StringWriter();
			serializer.setOutputProperty(OutputKeys.INDENT, "yes");
			serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			serializer.transform(node, new StreamResult(output));

			results.append(output.toString());
		}
		
		return results.toString();
	}
	
	private String normalizeAddress(String address){
		System.out.println("normalizeAddress, address="+address);
		Pattern xpath = Pattern.compile("^xpath\\(.*");
		Matcher m = xpath.matcher(address);
		if(m.matches()){
			System.out.println("XPath address encountered");
			return address;
		}
		
		if(!address.trim().equals("")){
			address = "xpath(//a[@name='" + address + "' or "
					 + "@id='" + address + "']/.."
					 + " | "
					 + "//p[@name='" + address + "' or "
					 + "@id='" + address + "'])";
		}else{
			address = "xpath(/body)";
		}
		
		System.out.println("normalized address="+address);
		return address;
	}
	
	public static void main(String args[]){
		if(args.length == 0){
			System.out.println("Usage:");
			System.out.println("org.hyperscope.purple.include.PurpleInclude url address [beSafe]");
			System.exit(1);
		}
		
		String url = args[0];
		String address = args[1];
		boolean beSafe = false;
		
		if(args.length > 2){
			beSafe = new Boolean(args[1]).booleanValue();
		}
		
		try{
			PurpleInclude include = new PurpleInclude();
			String results = include.exec(url, address, beSafe);
			System.out.println(results);
			System.exit(0);
		}catch(Exception e){
			System.out.println(e);
			System.exit(1);
		}
	}
}