package org.hyperscope.purple.include.address;

public class AddressException extends RuntimeException{
	public AddressException(){
		super();
	}
	
	public AddressException(String msg){
		super(msg);
	}
	
	public AddressException(Throwable t){
		super(t);
	}
}