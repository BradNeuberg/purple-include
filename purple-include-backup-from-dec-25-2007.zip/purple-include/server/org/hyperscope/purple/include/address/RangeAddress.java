package org.hyperscope.purple.include.address;

import java.net.URL;

class RangeAddress implements Address{	
	/**
		A private class that holds our range
		information so we can parse it from the
		URL and then work with it.
	*/
	class Range{
		public String startLocation;
		public int startOffset;
		public String endLocation;
		public int endOffset;
		
		public Range(String startLocation, int startOffset,
						String endLocation, int endOffset){
							
		}
	}
	
	public String resolve(String infileAddress, 
							String content, 
							String mimeType) throws AddressException{
		// assert correct MIME type
		
		// parse out the start and end locations and offsets to work with
		RangeAddress.Range range = parseRange(url);
		
		// resolve each to an XPath location
		XPath1Address start = new XPath1Address(range.startLocation);
		XPath1Address end = new XPath1Address(range.endLocation);
		
		
		
		throw new AddressException();
	}
	
	protected RangeAddress.Range parseRange(URL url){
		// returns the start and end of the range
		// to work with
		
		// assert xpath1 address scheme on each component for now
		return null;
	}
	
	protected Document resolveAddress
}