package org.hyperscope.purple.include.address;

import java.net.URL;

public class Resolver{
	public static String resolve(URL url) throws AddressException{
		return null;
	}
}