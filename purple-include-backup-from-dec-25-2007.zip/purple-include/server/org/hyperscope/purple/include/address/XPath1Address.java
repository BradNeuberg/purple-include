package org.hyperscope.purple.include.address;

import java.net.URL;

class XPath1Address implements Address{
	public String resolve(String infileAddress, 
							String content, 
							String mimeType) throws AddressException{
		throw new AddressException();
	}
	
	public Node resolveXPath(String location, Document content)
											throws AddressException{
												
	}
}