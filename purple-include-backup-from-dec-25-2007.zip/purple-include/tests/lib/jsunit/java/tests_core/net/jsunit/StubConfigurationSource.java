package net.jsunit;

import net.jsunit.configuration.ConfigurationSource;

public class StubConfigurationSource implements ConfigurationSource {

    public String browserFileNames() {
        return null;
    }

    public String closeBrowsersAfterTestRuns() {
        return null;
    }

    public String description() {
        return null;
    }

    public String logsDirectory() {
        return null;
    }

    public String logStatus() {
        return null;
    }

    public String port() {
        return null;
    }

    public String remoteMachineURLs() {
        return null;
    }

    public String resourceBase() {
        return null;
    }

    public String timeoutSeconds() {
        return null;
    }

    public String url() {
        return null;
    }

    public String ignoreUnresponsiveRemoteMachines() {
        return null;
    }

}
