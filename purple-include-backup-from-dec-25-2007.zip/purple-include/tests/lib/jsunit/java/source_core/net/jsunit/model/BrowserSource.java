package net.jsunit.model;

public interface BrowserSource {

    Browser getBrowserById(int id);
}
